/* 
 * File:   timers.h
 ** Author: Shridhar Naragund
 *
 * Created on 2 october, 2023, 10:25 AM
 */

#ifndef TIMERS_H
#define	TIMERS_H

void init_timer0(void);
void init_timer2(void);

#endif	/* TIMERS_H */

